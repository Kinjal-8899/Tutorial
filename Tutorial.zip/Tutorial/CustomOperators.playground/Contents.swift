import UIKit
import Combine
/*
extension Publisher where Output == Int {
    func filterEvenNumbers() -> AnyPublisher<Int, Failure> {
        return self.filter { $0 % 2 == 0 }
            .eraseToAnyPublisher()
    }
    
    func filterNumberGreaterThan(_ value: Int) -> AnyPublisher<Int, Failure> {
        return self.filter { $0 > value}
            .eraseToAnyPublisher()
    }
}

let publisher = [1,2,3,4,5,6,7,8,9,0].publisher
let cancellable = publisher.filterEvenNumbers()
    .sink { val in
        print(val)
    }

let cancellable2 = publisher.filterNumberGreaterThan(5)
    .sink { val in
        print(val)
    }
*/


extension Publisher {
    
    func mapAndFilter<T>(_ transform: @escaping (Output) -> T, _ isIncluded: @escaping (T) -> Bool) -> AnyPublisher<T, Failure> {
        return self
            .map { transform($0) }
            .filter { isIncluded($0)}
            .eraseToAnyPublisher()
    }
}

let publisher = [1,2,3,4,5,6,7,8,9,0].publisher

let cancellable = publisher
    .mapAndFilter({ $0 * 3 }) { val in
        return val % 2 == 0
    }
    .print("Debug")
    .sink { val in
        print(val)
    }

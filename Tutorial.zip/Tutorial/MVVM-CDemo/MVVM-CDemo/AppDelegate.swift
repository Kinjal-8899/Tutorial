//
//  AppDelegate.swift
//  MVVM-CDemo
//
//  Created by Sachingiri Goswami on 19/05/24.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {



    var window: UIWindow?
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        window = UIWindow(frame: UIScreen.main.bounds)
        let appCoordinator = AppCoordinator(window!)
        appCoordinator.start()
        window?.makeKeyAndVisible()
        
        return true
    }
    
}


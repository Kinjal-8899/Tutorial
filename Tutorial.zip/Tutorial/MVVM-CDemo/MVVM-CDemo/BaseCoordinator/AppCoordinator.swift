//
//  AppCoordinator.swift
//  AICleaner
//
//  Created by Sachingiri Goswami on 19/05/24.
//

import Foundation
import UIKit

class AppCoordinator: BaseCoordinator {

    private var window: UIWindow

    init(_ window: UIWindow) {
        self.window = window
    }

    override func start() {
        let home = SplashCoordinator()
        self.start(coordinator: home)
        window.rootViewController = home.navigationController
        window.makeKeyAndVisible()
    }
    
     func startHome() {
//        let home = HomeCoordinator()
//        self.start(coordinator: home)
//        window.rootViewController = home.navigationController
//        window.makeKeyAndVisible()
    }

}

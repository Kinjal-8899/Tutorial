//
//  
//  HomeCoordinator.swift
//  MVVM-CDemo
//
//  Created by Sachingiri Goswami on 20/05/24.
//
//
import Foundation
import UIKit

class HomeCoordinator: BaseCoordinator {
    
    /// Variable(s)
    private var viewModel =  HomeViewModel()
    private weak var homeVC: HomeVC!
    
    init(username:String,password: String) {
        
        self.viewModel.username = username
        self.viewModel.password = password
        
    }
    
    override func start() {
        setupBinding()
        
        let storyboard =  UIStoryboard(name: "Main", bundle: .main)
        homeVC = storyboard.instantiateViewController(withIdentifier: "HomeVC") as? HomeVC
        homeVC.viewModel = viewModel
        self.navigationController.pushViewController(homeVC, animated: true)
    }
}

// MARK: Method(s)
extension HomeCoordinator {
    
    private func setupBinding() {
        
        viewModel.viewDidSelect.subscribe(to: self) {  _, item in
        }
        
        viewModel.viewDidDisappear.subscribe(to: self) { this, _ in
            this.parentCoordinator?.didFinish(coordinator: this)
        }
    }
}

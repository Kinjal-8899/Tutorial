//
//  
//  HomeModel.swift
//  MVVM-CDemo
//
//  Created by Sachingiri Goswami on 20/05/24.
//
//
import Foundation
import UIKit

class HomeModel {

}

//
//  
//  HomeVC.swift
//  MVVM-CDemo
//
//  Created by Sachingiri Goswami on 20/05/24.
//
//
import Foundation
import UIKit

class HomeVC: BaseVC {

    /// IBOutlet(s)
    
    @IBOutlet weak var lblPassword: UILabel!
    @IBOutlet weak var lblUserName: UILabel!
    /// Variable(s)
    var viewModel: HomeViewModel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        prepareUI()
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        viewModel.viewDidDisappear.accept?(())
    }
}

// MARK: UI & Utility Method(s)
extension HomeVC {
    func prepareUI() {
        /// Initial UI Setup
        ///
        print("Username: \(viewModel.username)")
        print("Password: \(viewModel.password)")
        lblPassword.text = viewModel.username
        lblUserName.text = viewModel.password
    }
}

// MARK: IBAction(s)
extension HomeVC {
    
}

// MARK: TableView Related Method(s)
extension HomeVC {
    
}

// MARK: Api Call(s)
extension HomeVC {
    
}

//
//  
//  HomeViewModel.swift
//  MVVM-CDemo
//
//  Created by Sachingiri Goswami on 20/05/24.
//
//
import Foundation
import UIKit


class HomeViewModel {
    
    /// Variable(s)
    let viewDidDisappear = DelegateView<Void>()
    let viewDidSelect = DelegateView<Void>()
    var username:String = ""
    var password: String = ""
}

// MARK: Method(s)
extension HomeViewModel {
    
}

//
//  
//  LoginCoordinator.swift
//  MVVM-CDemo
//
//  Created by Sachingiri Goswami on 19/05/24.
//
//
import Foundation
import UIKit

class LoginCoordinator: BaseCoordinator {
    
    /// Variable(s)
    private var viewModel =  LoginViewModel()
    private weak var loginVC : LoginVC!
    
    override func start() {
        setupBinding()
        
        let storyboard =  UIStoryboard(name: "Main", bundle: .main)
        loginVC = storyboard.instantiateViewController(withIdentifier: "LoginVC") as? LoginVC
        loginVC.viewModel = viewModel
        self.navigationController.pushViewController(loginVC, animated: true)
    }
}

// MARK: Method(s)
extension LoginCoordinator {
    
    private func setupBinding() {
        
        viewModel.viewDidSelect.subscribe(to: self) {  _, item in
        }
        
        viewModel.viewDidDisappear.subscribe(to: self) { this, _ in
            this.parentCoordinator?.didFinish(coordinator: this)
        }
        viewModel.viewDidSelectLogin.subscribe(to: self) {  _, item in
            self.redirectToHome(username:item.0,password: item.1)
        }
    }
}

// MARK: Redirection
extension LoginCoordinator{
    
    private func redirectToHome(username:String,password: String){
        let homeCoordinator =  HomeCoordinator(username: username, password: password)
        homeCoordinator.navigationController = navigationController
        self.start(coordinator: homeCoordinator)
    }
    
}

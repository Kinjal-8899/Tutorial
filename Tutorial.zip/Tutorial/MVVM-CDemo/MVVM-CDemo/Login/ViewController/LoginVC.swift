//
//  
//  LoginVC.swift
//  MVVM-CDemo
//
//  Created by Sachingiri Goswami on 19/05/24.
//
//
import Foundation
import UIKit

class LoginVC: BaseVC {

    /// IBOutlet(s)
    
    @IBOutlet weak var txUsername: UITextField!
    @IBOutlet weak var txPassword: UITextField!
    /// Variable(s)
    var viewModel: LoginViewModel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        prepareUI()
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        viewModel.viewDidDisappear.accept?(())
    }
    
   
}

// MARK: UI & Utility Method(s)
extension LoginVC {
    func prepareUI() {
        /// Initial UI Setup
    }
}

// MARK: IBAction(s)
extension LoginVC {
    
    @IBAction func actionLogin(_ sender: Any) {
        self.viewModel.viewDidSelectLogin.accept?((
            txUsername.text ?? "Sachin_Goswami", txPassword.text ?? "Sachin@123"))
    }
}

// MARK: TableView Related Method(s)
extension LoginVC {
    
}

// MARK: Api Call(s)
extension LoginVC {
    
}

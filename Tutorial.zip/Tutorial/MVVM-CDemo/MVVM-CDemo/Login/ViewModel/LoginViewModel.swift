//
//  
//  LoginViewModel.swift
//  MVVM-CDemo
//
//  Created by Sachingiri Goswami on 19/05/24.
//
//
import Foundation
import UIKit


class LoginViewModel {
    
    /// Variable(s)
    let viewDidDisappear = DelegateView<Void>()
    let viewDidSelect = DelegateView<Void>()
    let viewDidSelectLogin = DelegateView<(String,String)>()

}

// MARK: Method(s)
extension LoginViewModel {
     
}

//
//  
//  SplashCoordinator.swift
//  MVVM-CDemo
//
//  Created by Sachingiri Goswami on 19/05/24.
//
//
import Foundation
import UIKit

class SplashCoordinator: BaseCoordinator {
    
    /// Variable(s)
    private var viewModel =  SplashViewModel()
    private weak var splashVC: SplashVC!
    
    override func start() {
        
        setupBinding()
            
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        splashVC = storyboard.instantiateViewController(withIdentifier: "SplashVC") as? SplashVC
        splashVC.viewModel = viewModel
        self.navigationController.viewControllers = [splashVC]
        
    }
}

// MARK: Method(s)
extension SplashCoordinator {
    
    private func setupBinding() {
        
        viewModel.viewDidSelect.subscribe(to: self) {  _, item in
        }
        
        viewModel.viewDidDisappear.subscribe(to: self) { this, _ in
            this.parentCoordinator?.didFinish(coordinator: this)
        }
        
        viewModel.viewDidMoveLogin.subscribe(to: self) {  _, item in
            self.movetoLoginScreen()
        }
    }
}

// Redirection
extension SplashCoordinator{
    private func movetoLoginScreen(){
        let loginCoordinator = LoginCoordinator()
        loginCoordinator.navigationController = self.navigationController
        self.start(coordinator: loginCoordinator)
    }
    
}

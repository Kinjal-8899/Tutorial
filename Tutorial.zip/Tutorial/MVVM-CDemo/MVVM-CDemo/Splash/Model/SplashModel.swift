//
//  
//  SplashModel.swift
//  MVVM-CDemo
//
//  Created by Sachingiri Goswami on 19/05/24.
//
//
import Foundation
import UIKit

class SplashModel {

}

//
//  
//  SplashVC.swift
//  MVVM-CDemo
//
//  Created by Sachingiri Goswami on 19/05/24.
//
//
import Foundation
import UIKit

class SplashVC: UIViewController {

    /// IBOutlet(s)
    
    /// Variable(s)
    var viewModel: SplashViewModel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        prepareUI()
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
//        viewModel.viewDidDisappear.accept?(()/*)*/
    }
}

// MARK: UI & Utility Method(s)
extension SplashVC {
    func prepareUI() {
        /// Initial UI Setup
        ///
        DispatchQueue.main.asyncAfter(deadline: .now() + 3, execute: {
            
            self.viewModel.viewDidMoveLogin.accept?(())
            
            
        })
    }
}

// MARK: IBAction(s)
extension SplashVC {
    
}

// MARK: TableView Related Method(s)
extension SplashVC {
    
}

// MARK: Api Call(s)
extension SplashVC {
    
}

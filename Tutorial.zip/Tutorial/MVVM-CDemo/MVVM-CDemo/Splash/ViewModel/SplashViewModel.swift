//
//  
//  SplashViewModel.swift
//  MVVM-CDemo
//
//  Created by Sachingiri Goswami on 19/05/24.
//
//
import Foundation
import UIKit


class SplashViewModel {
    
    /// Variable(s)
    let viewDidDisappear = DelegateView<Void>()
    let viewDidSelect = DelegateView<Void>()
    let viewDidMoveLogin = DelegateView<Void>()

}

// MARK: Method(s)
extension SplashViewModel {
    
}

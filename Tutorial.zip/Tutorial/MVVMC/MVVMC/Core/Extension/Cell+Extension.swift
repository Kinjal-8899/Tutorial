//
//  Cell+Extension.swift
//  MVVMC
//
//  Created by Ashish Patel on 08/11/22.
//
 
import UIKit

extension UITableViewCell {

   static var identifier : String {
        return String(describing: self)
   }
}

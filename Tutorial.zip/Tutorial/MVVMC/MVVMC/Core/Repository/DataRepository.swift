//
//  DataRepository.swift
//  MVVMC
//
//  Created by Ashish Patel on 07/11/22.
//

import Foundation

class DataRepository {
    
    func fetchFlight() -> [FlightModel] {
        
        let data = JsonUtils().getJson(filename: "flight_list", model: [FlightModel].self)
        return data ?? []
    }
}

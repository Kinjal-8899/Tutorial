//
//  File.swift
//  MVVMC
//
//  Created by Ashish Patel on 07/11/22.
//

import Foundation

class FlightDetailCoordinator: BaseCoordinator {
    
    private var viewModel = FlightDetailViewModel()
    
    init(data: FlightModel) {
        self.viewModel.data = data
    }
    
    override func start() {
        
        setupBinding()
        
        let detail = FlightDetailVC()
        detail.viewModel = viewModel 
        navigationController.present(detail, animated: true)
    }
    
    private func setupBinding() {
        
        viewModel.viewDidDisappear.subscribe(to: self) { this, _ in
            this.parentCoordinator?.didFinish(coordinator: this)
        }
    }
}

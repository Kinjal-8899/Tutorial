//
//  FlightDetailVC.swift
//  MVVMC
//
//  Created by Ashish Patel on 07/11/22.
//

import UIKit

class FlightDetailVC: UIViewController {
    
    @IBOutlet weak var imgFlight: UIImageView!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblDescription: UILabel!
    
    var viewModel: FlightDetailViewModel!
 
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        viewModel.viewDidDisappear.accept?(())
    }
}

extension FlightDetailVC {
    
    private func setupUI() {
        
        if let data = viewModel.data {
            imgFlight.load(fromUrl: data.imageUrl)
            lblName.text = data.name
            lblDescription.text = data.description
        }
    }
}

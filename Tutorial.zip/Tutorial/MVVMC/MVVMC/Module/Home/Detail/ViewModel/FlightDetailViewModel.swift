//
//  FlightDetailViewModel.swift
//  MVVMC
//
//  Created by Ashish Patel on 07/11/22.
//

import Foundation

class FlightDetailViewModel {
    
    var data: FlightModel?
    
    var viewDidDisappear = DelegateView<Void>()
}

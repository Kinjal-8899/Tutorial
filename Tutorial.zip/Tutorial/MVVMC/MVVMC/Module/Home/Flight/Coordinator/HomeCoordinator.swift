//
//  HomeCoordinator.swift
//  MVVMC
//
//  Created by Ashish Patel on 07/11/22.
//

import UIKit

class HomeCoordinator: BaseCoordinator {
    
    private var viewModel: HomeViewModel!
    
    override func start() {
        
        setupData()
        setupBinding()
        
        let homeVC = HomeVC()
        homeVC.viewModel = viewModel
        
        self.navigationController = UINavigationController(rootViewController: homeVC)
        self.navigationController.viewControllers = [homeVC]
    }
    
    private func setupData() {
        
        let repository = DataRepository()
        viewModel = HomeViewModel(repository: repository)
    }
    
    private func setupBinding() {
        
        viewModel.homeItemSelected.subscribe(to: self) { this, data in
            this.navigateToDetail(data: data)
        }
        
        viewModel.viewDidDisappear.subscribe(to: self) { this, _ in
            this.parentCoordinator?.didFinish(coordinator: this)
        }
    }
    
    private func navigateToDetail(data: FlightModel) {
        let detail = FlightDetailCoordinator(data: data)
        detail.navigationController = navigationController
        start(coordinator: detail)
    }
}

//
//  FlightItemCell.swift
//  MVVMC
//
//  Created by Ashish Patel on 07/11/22.
//

import UIKit

class FlightItemCell: UITableViewCell {
    
    @IBOutlet weak var imgFlight: UIImageView!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblDescription: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    func binding(model: FlightModel) {
        
        imgFlight.load(fromUrl: model.imageUrl)
        lblName.text = model.name
        lblDescription.text = model.description
    }
}

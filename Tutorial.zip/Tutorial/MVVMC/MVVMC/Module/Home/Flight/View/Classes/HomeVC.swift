//
//  HomeVC.swift
//  MVVMC
//
//  Created by Ashish Patel on 07/11/22.
//

import UIKit

class HomeVC: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    
    var viewModel: HomeViewModel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupUI()
        setupData()
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        
        super.viewDidDisappear(animated)
        viewModel.viewDidDisappear.accept?(())
    }
}

extension HomeVC {
    
    private func setupUI() {
        
        navigationItem.title = "Flights"
        navigationController?.navigationBar.barTintColor = .white
        
        tableView.delegate = self
        tableView.dataSource = self
        tableView.rowHeight = UITableView.automaticDimension
        tableView.estimatedRowHeight = 104
        tableView.separatorStyle = .none
        tableView.register(
            UINib(nibName: FlightItemCell.identifier, bundle: nil),
            forCellReuseIdentifier: FlightItemCell.identifier
        )
    }
    
    private func setupData() {
         
        self.viewModel.showData = { [weak self] in
            guard let `self` = self else { return }
            self.tableView.reloadData()
        }
    } 
}

extension HomeVC: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        viewModel.data.count
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let cell = tableView.dequeueReusableCell(withIdentifier: FlightItemCell.identifier, for: indexPath) as? FlightItemCell {
            let model = viewModel.data[indexPath.row]
            cell.binding(model: model)
            return cell
        }
        return UITableViewCell()
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        viewModel.homeItemSelected.accept?(viewModel.data[indexPath.row])
    }
}

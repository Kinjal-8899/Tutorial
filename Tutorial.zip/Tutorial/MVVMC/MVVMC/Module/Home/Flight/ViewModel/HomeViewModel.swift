//
//  HomeViewModel.swift
//  MVVMC
//
//  Created by Ashish Patel on 07/11/22.
//

import Foundation

class HomeViewModel {
    
    private var repo: DataRepository!
    
    var data: [FlightModel] = []
    
    var showData: (() -> ())?
    
    let viewDidDisappear = DelegateView<Void>()
    let homeItemSelected = DelegateView<FlightModel>()
 
    init(repository: DataRepository) {
        self.repo = repository
        self.fetchFlight()
    }
    
    func fetchFlight() {
        self.data = repo.fetchFlight()
        self.showData?()
    }
}

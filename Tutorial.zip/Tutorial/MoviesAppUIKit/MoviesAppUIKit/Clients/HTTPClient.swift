//
//  HTTPClient.swift
//  MoviesAppUIKit
//
//  Created by Kinjal Panchal on 01/10/24.
//

import Foundation
import Combine

enum NetworkError: Error {
    case badURL
}

class HTTPClient {
    
    func fetchMovies(search: String) -> AnyPublisher<[Movie], Error> {
        
        guard let encodedSearch = search.urlEncoded else {
            return Fail(error: NetworkError.badURL).eraseToAnyPublisher()
        }
        
        guard let url = URL(string: "http://www.omdbapi.com/?apikey=564727fa&s=\(encodedSearch)&page=1") else {
            return Fail(error: NetworkError.badURL).eraseToAnyPublisher()
        }
        
        return URLSession.shared.dataTaskPublisher(for: url)
            .map(\.data)
            .decode(type: MovieResponse.self, decoder: JSONDecoder())
            .map(\.search)
            .receive(on: DispatchQueue.main)
            .catch({ error -> AnyPublisher<[Movie], Error> in
                return Just([]).setFailureType(to: Error.self).eraseToAnyPublisher()
            })
            .eraseToAnyPublisher()
    }
}

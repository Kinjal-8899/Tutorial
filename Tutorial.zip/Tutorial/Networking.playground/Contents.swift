import UIKit
import Combine

var greeting = "Hello, playground"

struct Post: Codable {
    let userId: Int
    let id: Int
    let title: String
    let body: String
}

enum NetworkError: Error {
    case badServerResponse
}
/*
func fetchPosts() -> AnyPublisher<[Post], Error> {
    let url = URL(string: "https://jsonplaceholder.typicode.com/postss")!
    
    return URLSession.shared.dataTaskPublisher(for: url)
        .tryMap{ data, response in
            print("Retry")
            guard let httpResponse = response as? HTTPURLResponse,
                  httpResponse.statusCode == 200 else {
                throw NetworkError.badServerResponse
            }
            return data
        }
        .decode(type: [Post].self, decoder: JSONDecoder())
        .retry(3)
        .receive(on: DispatchQueue.main)
        .eraseToAnyPublisher()
}



fetchPosts()
    .sink { completion in
        switch completion {
        case .finished:
            print("Updated UI")
        case .failure(let error):
            print(error)
        }
    } receiveValue: { posts in
        print(posts)
    }
    .store(in: &cancellables)
*/
var cancellables: Set<AnyCancellable> = []
struct MovieResponse: Decodable {
    let Search: [Movie]
}

struct Movie: Decodable {
    let title: String
    
    private enum CodingKeys: String, CodingKey {
        case title = "Title"
    }
}

func fetchMovies(_ searchTerm: String) -> AnyPublisher<MovieResponse, Error> {
    let url = URL(string: "https://www.omdbapi.com/?s=\(searchTerm)&page=2&apiKey=564727fa")!
    
    return URLSession.shared.dataTaskPublisher(for: url)
        .tryMap{ data, response in
            print("Retry")
            guard let httpResponse = response as? HTTPURLResponse,
                  httpResponse.statusCode == 200 else {
                throw NetworkError.badServerResponse
            }
            return data
        }
        .decode(type: MovieResponse.self, decoder: JSONDecoder())
        .retry(3)
        .receive(on: DispatchQueue.main)
        .eraseToAnyPublisher()
}

Publishers.CombineLatest(fetchMovies("Batman"), fetchMovies("Spiderman"))
    .sink { _ in
        
    } receiveValue: { (val1, val2) in
        print(val1)
        print(val2)
    }
    .store(in: &cancellables)


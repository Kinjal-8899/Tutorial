import UIKit
import Combine

/*
let numberPublisher = (1...5).publisher

// Map
let squaredPublisher = numberPublisher.map { $0 * $0 }

let cancellable = squaredPublisher.sink { value in
    print(value)
}
 */


/*
 let namePublisher = ["Kinjal", "Nirav", "Anjali"].publisher
 
 // FlatMap
 let flattenNamePublisher = namePublisher.flatMap { name in
 name.publisher
 }
 
 let cancellable = flattenNamePublisher.sink { char in
 print(char)
 }
 */


/*
 let publisher1 = [1,2,3].publisher
 let publisher2 = [4,5,6].publisher
 
 // Merge
 let mergedPublisher = Publishers.Merge(publisher1, publisher2)
 
 let cancellable = mergedPublisher.sink { value in
 print(value)
 }
 */


/*
let numberPublisher = (1...10).publisher

// Filter
let evenNumberPublisher = numberPublisher.filter { $0 % 2 == 0 }

let cancellable = evenNumberPublisher.sink { value in
    print(value)
}
*/


/*
let stringPublisher = ["1", "2", "K", "4"].publisher

// CompactMap
let numberPublisher = stringPublisher.compactMap { Int($0) }

let cancellable = numberPublisher.sink { value in
    print(value)
}
*/


/*
 let textPublisher = PassthroughSubject<String, Never>()
 
 // Debounce - delay the execuation like search in workItem
 let debouncePublisher = textPublisher.debounce(for: .seconds(0.5), scheduler: DispatchQueue.main)
 
 let cancellable = debouncePublisher.sink { value in
 print(value)
 }
 
 textPublisher.send("A")
 textPublisher.send("B")
 textPublisher.send("C")
 DispatchQueue.main.asyncAfter(deadline: .now() + 0.6) {
 textPublisher.send("K")
 }
 */

/*
let publisher1 = CurrentValueSubject<Int, Never>(1)
let publisher2 = CurrentValueSubject<String, Never>("Kinjal")

 // CombineLatest
let combinePublisher = publisher1.combineLatest(publisher2)

let cancellable = combinePublisher.sink { val1, val2 in
    print("Value1: \(val1), Value2: \(val2)")
}
publisher1.send(3)
publisher2.send("Nirav")
*/


/*
 let publisher1 = [1,2,3,4,5].publisher
 let publisher2 = ["a", "b", "c", "d"].publisher
 
 // Zip - work only for 2 items
 let zippedPublisher = publisher1.zip(publisher2)
 
 //Zip3 can be used for that Publishers.Zip3(,,)
 
 let cancellable = zippedPublisher.sink { val1, val2 in
 print("Value1: \(val1), Value2: \(val2)")
 }
 */


/*
let outerPublisher = PassthroughSubject<AnyPublisher<Int, Never>, Never>()
let innerPublisher1 = CurrentValueSubject<Int, Never>(1)
let innerPublisher2 = CurrentValueSubject<Int, Never>(3)

// SwitchToLatest
let cancellable = outerPublisher
    .switchToLatest()
    .sink { value in
        print(value)
    }

outerPublisher.send(AnyPublisher(innerPublisher1))
innerPublisher1.send(3)

outerPublisher.send(AnyPublisher(innerPublisher2))
innerPublisher1.send(10)
innerPublisher2.send(15)
*/


/*
enum NumberError: Error {
    case operationFailed
}

let numberPublisher = [1, 2, 3, 4, 5].publisher

let doubledPublisher = numberPublisher
    .tryMap { number in
        if number == 4 {
            throw NumberError.operationFailed
        }
        return number * 2
    }
    .catch { error in
        if let numberError = error as? NumberError {
            print("Error occurred: \(numberError)")
        }
        return Just(0)
    }

let cancellable = doubledPublisher.sink { completion in
    switch completion {
    case .finished:
        print("Finished")
    case .failure(let error):
        print(error)
    }
} receiveValue: { value in
    print("Received: \(value)")
}

*/

/*
 let doubledPublisher = numberPublisher
     .tryMap { number in
         if number == 4 {
             throw NumberError.operationFailed
         }
         return number * 2
     }.mapError { error in
         return error
     }

 let cancellable = doubledPublisher.sink { completion in
     switch completion {
     case .finished:
         print("Finished")
     case .failure(let error):
         print(error)
     }
 } receiveValue: { value in
     print("Received: \(value)")
 }
 */

// replaceError with single error
/*
let numberPublisher = [1, 2, 3, 4, 5, 6].publisher

let transfomedPublisher = numberPublisher
    .tryMap { number in
        if number == 4 {
            throw NumberError.operationFailed
        }
        return number * 2
    }.replaceError(with: -1)
let cancellable = transfomedPublisher.sink { value in
    print("Received: \(value)")
}
*/

// replaceError with another publisher
/*
 let numberPublisher = [1, 2, 3, 4, 5, 6].publisher
 let fallBackPublisher = Just(-1)
 
 let transfomedPublisher = numberPublisher
 .tryMap { number in
 if number == 4 {
 throw NumberError.operationFailed
 }
 return Just(number * 2)
 }.replaceError(with: fallBackPublisher)
 
 let cancellable = transfomedPublisher.sink { value in
 print("Received: \(value)")
 }
 */


/*
// retry
let publisher = PassthroughSubject<Int, Error>()

let retriedPublisher = publisher
    .tryMap { value in
        if value == 3 {
            throw NumberError.operationFailed
        }
        return value
    }.retry(2)

let cancellable = retriedPublisher.sink { completion in
    switch completion {
    case .finished:
        print("Finished")
    case .failure(let error):
        print(error)
    }
} receiveValue: { value in
    print("Received: \(value)")
}

publisher.send(1)
publisher.send(3) // 1
publisher.send(5)
publisher.send(3) // 2
publisher.send(15)
publisher.send(3) // 3
publisher.send(25)
*/

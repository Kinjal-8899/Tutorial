import UIKit
import Combine

/*
// For passing single value
let publisher = Just("Kinjal")

let anyCancellable = publisher.sink { value in
    print(value)
}
*/

/*
// Emit sequence data
let numberPublisher = [1,2,3,4,5].publisher
let doublePublisher = numberPublisher.map { $0 * 2 }
let cancellable = doublePublisher.sink { value in
    print(value)
}
*/

/*
 // Timer Publisher
 let timerPublisher = Timer.publish(every: 1, on: .main, in: .common)
 
 let cancellable = timerPublisher.autoconnect().sink { timestamp in
 print("TimeStamp: \(timestamp)")
 }
 */

enum NumberError: Error {
    case operationFailed
}

let numberPublisher = [1, 2, 3, 4, 5].publisher

let doubledPublisher = numberPublisher
    .tryMap { number in
        if number == 4 {
            throw NumberError.operationFailed
        }
        return number * 2
    }.mapError { error in
        return error
    }

let cancellable = doubledPublisher.sink { completion in
    switch completion {
    case .finished:
        print("Finished")
    case .failure(let error):
        print(error)
    }
} receiveValue: { value in
    print("Received: \(value)")
}

/*
let doubledPublisher = numberPublisher
    .tryMap { number in
        if number == 4 {
            throw NumberError.operationFailed
        }
        return number * 2
    }
    .catch { error in
        if let numberError = error as? NumberError {
            print("Error occurred: \(numberError)")
        }
        return Just(0)
    }

let cancellable = doubledPublisher.sink { completion in
    switch completion {
    case .finished:
        print("Finished")
    case .failure(let error):
        print(error)
    }
} receiveValue: { value in
    print("Received: \(value)")
}

*/

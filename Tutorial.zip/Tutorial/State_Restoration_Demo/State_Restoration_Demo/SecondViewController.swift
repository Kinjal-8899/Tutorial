//
//  SecondViewController.swift
//  State_Restoration_Demo
//
//  Created by Kinjal Panchal on 30/08/24.
//

import UIKit

class SecondViewController: UIViewController {

    @IBOutlet weak var txtName: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func btnAction_Clear(_ sender: UIButton) {
        txtName.text = ""
    }

}

extension SecondViewController {
    
    override func encodeRestorableState(with coder: NSCoder) {
        coder.encode(txtName.text, forKey: "TextFieldText")
        super.encodeRestorableState(with: coder)
        
       
    }
    
    override func decodeRestorableState(with coder: NSCoder) {
        if let text = coder.decodeObject(forKey: "TextFieldText") as? String {
            txtName.text = text
        }
        super.decodeRestorableState(with: coder)
        
       
    }
    
    override func applicationFinishedRestoringState() {
        super.applicationFinishedRestoringState()
        
    }
    
}

extension SecondViewController: UIViewControllerRestoration {
    
    static func viewController(withRestorationIdentifierPath identifierComponents: [String], coder: NSCoder) -> UIViewController? {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let secondVC = storyboard.instantiateViewController(withIdentifier: "SecondViewController") as! SecondViewController
        return secondVC
    }
    
}

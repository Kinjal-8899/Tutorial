import UIKit
import Combine

// Subjects: publish and they can also subscribe

// PassthroughSubject
/*
let subject = PassthroughSubject<Int, Never>()

let cancellable = subject.sink { value in
    print(value)
}

subject.send(1)
 */

// CurrentValueSubject
/*
let subject = CurrentValueSubject<Int, Never>(1)

let cancellable = subject.sink { value in
    print(value)
}

subject.send(2)
 */


// Create own Subject
/*
class EvenSubject<Failure: Error>: Subject {
    
    typealias Output = Int
    
    private let wrapped: PassthroughSubject<Int, Failure>
    
    init(initialValue: Int) {
        self.wrapped = PassthroughSubject()
        let evenInitialValue = initialValue % 2 == 0 ? initialValue : 0
        send(evenInitialValue)
    }
    
    func send(subscription: any Subscription) {
        wrapped.send(subscription: subscription)
    }
    
    func send(_ value: Int) {
        if value % 2 == 0 {
            wrapped.send(value)
        }
    }
    
    func send(completion: Subscribers.Completion<Failure>) {
        wrapped.send(completion: completion)
    }
    
    func receive<S>(subscriber: S) where S : Subscriber, Failure == S.Failure, Int == S.Input {
        wrapped.receive(subscriber: subscriber)
    }
    
}

let subject = EvenSubject<Never>(initialValue: 4)

let cancellable = subject.sink { value in
    print(value)
}
subject.send(12)
subject.send(13)
subject.send(20)
 */
class WeatherClient {
    
    let updates = PassthroughSubject<Int, Never>()
    
    func fetchWeather() {
        DispatchQueue.main.asyncAfter(deadline: .now() + 2) { [weak self] in
            self?.updates.send(Int.random(in: 32...100))
        }
    }
}


let client = WeatherClient()

let cancellable = client.updates.sink { value in
    print(value)
}

client.fetchWeather()

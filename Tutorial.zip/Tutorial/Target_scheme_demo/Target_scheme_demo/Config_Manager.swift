//
//  Config_Manager.swift
//  Target_scheme_demo
//
//  Created by Kinjal Panchal on 04/09/24.
//

import UIKit

private enum BuildConfiguraion {
    enum Error: Swift.Error {
        case missingKey, invalidValue
    }
    
    static func value<T>(for key: String) throws -> T where T: LosslessStringConvertible {
        guard let object = Bundle.main.object(forInfoDictionaryKey: key) else { return throw Error.missingKey }
        
        switch object {
        case let string as String:
            guard let value = T(string) else { fallthrough }
            return value
        default:
            throw Error.invalidValue
        }
    }
}

enum API {
    static var baseURL: String {
        do {
            return try BuildConfiguraion.value(for: "BASE_URL")
        } catch {
            fatalError(error.localizedDescription)
        }
    }
}

enum ConfigurationManager {
    enum Environment {
        case dev
        case qa
        case prod
    }
    
    static var environment: Environment {
        #if DEV
            return .dev
        #elseif PROD
            return .prod
        #elseif QA
            return .qa
        #endif
    }
}
